import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSortDown } from '@fortawesome/free-solid-svg-icons';

class SecondaryPoint extends Component {
  onShowClick = () => {
    this.props.showClickHandler();
  };

  render() {
    return (
      <div className="my-2">
        <h5 className="w-50 mx-auto d-flex justify-content-center border border-success  font-italic font-weight-bold bg-primary text-white ">
          <div className="d-flex">
            <div>{this.props.title}</div>
            <i style={{ cursor: 'pointer' }} onClick={this.onShowClick}>
              <FontAwesomeIcon icon={faSortDown} />
            </i>
          </div>
        </h5>
      </div>
    );
  }
}

export default SecondaryPoint;
