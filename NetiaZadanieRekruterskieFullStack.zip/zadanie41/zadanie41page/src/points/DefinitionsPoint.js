import React, { Component } from 'react';
import BootstrapTable from 'react-bootstrap-table-next/dist/react-bootstrap-table-next';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSortDown } from '@fortawesome/free-solid-svg-icons';

export default class DefinitionsPoint extends Component {
  state = {
    showPointContent: true
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div>
        <h6 className="my-3">
          <div className="d-flex justify-content-center">
            <div>
              <strong>1.1</strong> Definicje oraz skróty
            </div>
            <div
              onClick={() =>
                this.setState({
                  showPointContent: !this.state.showPointContent
                })
              }
            >
              <FontAwesomeIcon icon={faSortDown} />
            </div>
          </div>
        </h6>
        {showPointContent ? (
          <div className="d-flex justify-content-center">
            <BootstrapTable
              bootstrap4
              keyField="shortCutField"
              data={definitionsAndShotcuts}
              columns={columns}
              defaultSorted={defaultSorted}
            />
          </div>
        ) : null}
      </div>
    );
  }
}

const columns = [
  {
    dataField: 'shortCutField',
    text: 'Skrót',
    sort: true
  },
  {
    dataField: 'definitionsField',
    text: 'Definicja',
    sort: true
  }
];

const definitionsAndShotcuts = [
  {
    shortCutField: 'API',
    definitionsField: 'Application Programming Interface'
  },
  {
    shortCutField: 'REST',
    definitionsField:
      'https://en.wikipedia.org/wiki/Representational_state_transfer'
  },
  {
    shortCutField: 'JSON',
    definitionsField: 'https://en.wikipedia.org/wiki/JSON'
  },
  {
    shortCutField: 'SOAP',
    definitionsField: 'https://pl.wikipedia.org/wiki/SOAP'
  },
  {
    shortCutField: 'WS',
    definitionsField: 'Web Service'
  },
  {
    shortCutField: 'BD, DB',
    definitionsField: 'Baza Danych'
  },
  {
    shortCutField: 'SZRBD',
    definitionsField: 'System Zarządzania Relacyjną Bazą Danych'
  }
];

const defaultSorted = [
  {
    dataField: 'shortCutField',
    order: 'desc'
  }
];
