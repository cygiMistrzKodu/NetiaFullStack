import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSortDown } from '@fortawesome/free-solid-svg-icons';
import PropTypes from 'prop-types'

class MainPoint extends Component {
  onShowClick = () => {
    this.props.showClickHandler();
  };

  render() {
    return (
      <div>
        <h4 className="card-header font-weight-bold">
          <div className="d-flex">
            <div>{this.props.title}</div>
            <i style={{ cursor: 'pointer' }} onClick={this.onShowClick}>
              <FontAwesomeIcon icon={faSortDown} />
            </i>
          </div>
        </h4>
      </div>
    );
  }
}

MainPoint.propTypes = {
  title: PropTypes.string.isRequired,
  showClickHandler: PropTypes.func.isRequired
  
}

export default MainPoint;
