import React, { Component } from 'react';

class SecondaryPointBasic extends Component {
  render() {
    return (
      <div className="mt-3">
        <h5 className="w-50 mx-auto d-flex justify-content-center border border-success  font-italic font-weight-bold bg-primary text-white ">
          <div className="d-flex">
            <div>{this.props.title}</div>
          </div>
        </h5>
      </div>
    );
  }
}

export default SecondaryPointBasic;
