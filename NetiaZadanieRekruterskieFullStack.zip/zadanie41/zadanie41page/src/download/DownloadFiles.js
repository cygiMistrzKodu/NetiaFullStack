import React, { Component } from 'react';
import Section from '../sections/Section';
import wsdl from '../resources/CredWS.wsdl';
import sql from '../resources/zdania-sql-db.sql';

class DownloadFiles extends Component {
  render() {
    return (
      <div className="row justify-content-around">
        <a href={wsdl} download>
          <Section sections={wsdlTekst} />
        </a>

        <a href={sql} download>
          <Section sections={sqlTekst} />
        </a>
      </div>
    );
  }
}

export default DownloadFiles;

const wsdlTekst = [
  {
    id: 1,
    text: 'WSDL zadanie 2 JAVA'
  }
];

const sqlTekst = [
  {
    id: 1,
    text: 'Skrypt tworzący bazę danych dla zadań SQL'
  }
];
