import React, { Component } from 'react';

class List extends Component {
  render() {
    let linesText = this.props.listlinesText.map(line => (
      <li key={line.id}>{line.text}</li>
    ));

    return (
      <div className="d-flex justify-content-center">
        <div className="py-0 w-75 text-left">
          <p className="mt-3 mb-0 text-left">{this.props.title}</p>

          <ol
            className="py-0 my-0"
            style={{ listStyleType: this.props.listStyle }}
          >
            {linesText}
          </ol>
        </div>
      </div>
    );
  }
}

export default List;
