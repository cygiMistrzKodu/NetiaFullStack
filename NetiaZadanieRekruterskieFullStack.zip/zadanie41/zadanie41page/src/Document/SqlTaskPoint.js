import React, { Component } from 'react';
import MainPoint from '../points/MainPoint';
import sectionsTexts from '../texts/sectionsTexts';
import Section from '../sections/Section';
import SqlTasksSubPoints from '../DocumentSubPoints/SqlTasksSubPoints'

class SqlTaskPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div className="card w-50 mx-auto">
        <MainPoint
          title="3	Zadania SQL"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <Section sections={sectionsTexts.sqlTask.area1} />
            <SqlTasksSubPoints/>
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default SqlTaskPoint;
