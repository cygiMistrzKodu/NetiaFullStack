import React, { Component } from 'react';
import MainPoint from '../points/MainPoint';
import DownloadFiles from '../download/DownloadFiles';

class AttachmentPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div className="card w-50 mx-auto">
        <MainPoint
          title="5	Załączniki"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <DownloadFiles />
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default AttachmentPoint;
