import React, { Component } from 'react';
import MainPoint from '../points/MainPoint';
import sectionsTexts from '../texts/sectionsTexts';
import Section from '../sections/Section';
import FrontEndTaskSubPoints from '../DocumentSubPoints/FrontEndTaskSubPoints';

class FrontEndTasksPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div className="card w-50 mx-auto">
        <MainPoint
          title="4	Zadania frontend"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <Section sections={sectionsTexts.frontendTask.area1} />
            <FrontEndTaskSubPoints/>
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default FrontEndTasksPoint;
