import React, { Component } from 'react';
import MainPoint from '../points/MainPoint';
import sectionsTexts from '../texts/sectionsTexts';
import Section from '../sections/Section';
import AlgorithmicsTaskSubPoint from '../DocumentSubPoints/AlgorithmicsTaskSubPoint';
import JaxWSTaskSubPoint from '../DocumentSubPoints/JaxWSTaskSubPoint';
import DataProcessingTaskSubPoint from '../DocumentSubPoints/DataProcessingTaskSubPoint';
import WWWTaskSubPoint from '../DocumentSubPoints/WWWTaskSubPoint';

class ProgrammingTasksPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div className="card w-50 mx-auto">
        <MainPoint
          title="2	Zadania programistyczne"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <Section sections={sectionsTexts.programmingTask.area1} />
            <AlgorithmicsTaskSubPoint/>
            <JaxWSTaskSubPoint/>
            <DataProcessingTaskSubPoint/>
            <WWWTaskSubPoint/>
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default ProgrammingTasksPoint;
