import React, { Component } from 'react';
import MainPoint from '../points/MainPoint';
import sectionsTexts from '../texts/sectionsTexts';
import Section from '../sections/Section';
import DefinitionsPoint from '../points/DefinitionsPoint';

class StructureAndRangePoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div className="card w-50 mx-auto">
        <MainPoint
          title="1	Zakres i struktura dokumentu"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <Section sections={sectionsTexts.documentStructure.area1} />
            <DefinitionsPoint />
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default StructureAndRangePoint;
