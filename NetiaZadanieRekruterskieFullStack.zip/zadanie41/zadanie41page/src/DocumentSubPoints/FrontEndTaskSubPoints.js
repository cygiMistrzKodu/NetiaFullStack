import React, { Component } from 'react';
import SecondaryPointBasic from '../points/SecondaryPointBasic';
import Section from '../sections/Section';
import sectionsTexts from '../texts/sectionsTexts';
import List from '../lists/List';
import listTexts from '../texts/listTexts';

class FrontEndTaskSubPoints extends Component {
  render() {
    return (
      <div>
        <SecondaryPointBasic title="4.1  Zadanie 1" />
        <Section sections={sectionsTexts.frontendTask.area2} />
        <List
          listlinesText={listTexts.programmingTask.frontEnd.list1}
          listStyle="disc"
        />
        <SecondaryPointBasic title="4.2  Zadanie 2" />
        <Section sections={sectionsTexts.frontendTask.area3} />
        <List
          listlinesText={listTexts.programmingTask.frontEnd.list2}
          listStyle="lower-alpha"
        />
        <Section sections={sectionsTexts.frontendTask.area4} />
      </div>
    );
  }
}

export default FrontEndTaskSubPoints;
