import React, { Component } from 'react';
import SecondaryPoint from '../points/SecondaryPoint';
import Section from '../sections/Section';
import sectionsTexts from '../texts/sectionsTexts';
import tabelTexts from '../texts/tabelTexts';
import Table from '../tabels/Tabel';

class AlgorithmicsTaskSubPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div>
        <SecondaryPoint
          title="2.1 Zadanie 1 - Algorytmika"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <Section sections={sectionsTexts.programmingTask.area2} />

            <Table
              title={tabelTexts.programmingTask.algorithmics.tabel1Title}
              keyField={tabelTexts.programmingTask.algorithmics.tabel1keyField}
              columns={tabelTexts.programmingTask.algorithmics.tabel1Columns}
              data={tabelTexts.programmingTask.algorithmics.tabel1ColumnsData}
              tabelFooterTitle={
                tabelTexts.programmingTask.algorithmics.tabel1FooterDataTittle
              }
              footerData={
                tabelTexts.programmingTask.algorithmics.tabel1FooterData
              }
              footerStyleType={'decimal'}
            />
            <Section sections={sectionsTexts.programmingTask.area3} />

            <Table
              title={tabelTexts.programmingTask.algorithmics.tabel2Title}
              keyField={tabelTexts.programmingTask.algorithmics.tabel2keyField}
              columns={tabelTexts.programmingTask.algorithmics.tabel2Columns}
              data={tabelTexts.programmingTask.algorithmics.tabel2ColumnsData}
              tabelFooterTitle={
                tabelTexts.programmingTask.algorithmics.tabel2FooterDataTittle
              }
              footerData={
                tabelTexts.programmingTask.algorithmics.tabel2FooterData
              }
              footerStyleType={'decimal'}
            />
            <Section sections={sectionsTexts.programmingTask.area4} />
            <Table
              title={tabelTexts.programmingTask.algorithmics.tabel3Title}
              keyField={tabelTexts.programmingTask.algorithmics.tabel3keyField}
              columns={tabelTexts.programmingTask.algorithmics.tabel3Columns}
              data={tabelTexts.programmingTask.algorithmics.tabel3ColumnsData}
              tabelFooterTitle={
                tabelTexts.programmingTask.algorithmics.tabel3FooterDataTittle
              }
              footerData={
                tabelTexts.programmingTask.algorithmics.tabel3FooterData
              }
              footerStyleType={'decimal'}
            />
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default AlgorithmicsTaskSubPoint;
