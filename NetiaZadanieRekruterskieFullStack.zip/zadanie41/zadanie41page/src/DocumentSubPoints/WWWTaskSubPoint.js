import React, { Component } from 'react';
import SecondaryPoint from '../points/SecondaryPoint';
import Section from '../sections/Section';
import sectionsTexts from '../texts/sectionsTexts';
import List from '../lists/List';
import listTexts from '../texts/listTexts';

class WWWTaskSubPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div className="">
        <SecondaryPoint
          title="2.4	Zadanie 4 - WWW"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <List
              title={listTexts.programmingTask.WWW.list1Title}
              listlinesText={
                listTexts.programmingTask.WWW.list1
              }
              listStyle="disc"
            />
            <Section sections={sectionsTexts.programmingTask.area16} />
            <List
              title={listTexts.programmingTask.WWW.list2Title}
              listlinesText={
                listTexts.programmingTask.WWW.list2
              }
              listStyle="disc"
            />
            <Section sections={sectionsTexts.programmingTask.area17} />
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default WWWTaskSubPoint;
