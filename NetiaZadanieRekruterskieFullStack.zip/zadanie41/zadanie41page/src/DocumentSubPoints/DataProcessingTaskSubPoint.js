import React, { Component } from 'react';
import SecondaryPoint from '../points/SecondaryPoint';
import Section from '../sections/Section';
import sectionsTexts from '../texts/sectionsTexts';
import List from '../lists/List';
import listTexts from '../texts/listTexts';

class DataProcessingTaskSubPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div className="">
        <SecondaryPoint
          title="2.3	Zadanie 3 - Przetwarzanie danych"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <Section sections={sectionsTexts.programmingTask.area13} />

            <List
              title={listTexts.programmingTask.dataProcessing.list1Title}
              listlinesText={
                listTexts.programmingTask.dataProcessing.list1Start
              }
              listStyle="disc"
            />
            <List
              listlinesText={
                listTexts.programmingTask.dataProcessing.List1subList
              }
              listStyle="circle"
            />
            <List
              listlinesText={listTexts.programmingTask.dataProcessing.List1End}
              listStyle="disc"
            />
            <List
              title={listTexts.programmingTask.dataProcessing.list2Title}
              listlinesText={listTexts.programmingTask.dataProcessing.list2}
              listStyle="disc"
            />
            <List
              title={listTexts.programmingTask.dataProcessing.list3Title}
              listlinesText={listTexts.programmingTask.dataProcessing.list3}
              listStyle="disc"
            />
            <List
              title={listTexts.programmingTask.dataProcessing.list4Title}
              listlinesText={listTexts.programmingTask.dataProcessing.list4}
              listStyle="disc"
            />
            <Section sections={sectionsTexts.programmingTask.area14} />
            <List
              title={listTexts.programmingTask.dataProcessing.list5Title}
              listlinesText={listTexts.programmingTask.dataProcessing.list5Start}
              listStyle="disc"
            />
            <List
              listlinesText={listTexts.programmingTask.dataProcessing.list5SubList}
              listStyle="circle"
            />
            <List
              listlinesText={listTexts.programmingTask.dataProcessing.list5End}
              listStyle="disc"
            />
            <Section sections={sectionsTexts.programmingTask.area15} />
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default DataProcessingTaskSubPoint;
