import React, { Component } from 'react';
import SecondaryPointBasic from '../points/SecondaryPointBasic';
import Section from '../sections/Section';
import sectionsTexts from '../texts/sectionsTexts';
import List from '../lists/List';
import listTexts from '../texts/listTexts';

class SqlTasksSubPoints extends Component {
  render() {
    return (
      <div>
        <SecondaryPointBasic title="3.1  Zadanie 1" />
        <Section sections={sectionsTexts.sqlTask.area2} />
        <SecondaryPointBasic title="3.2  Zadanie 2" />
        <Section sections={sectionsTexts.sqlTask.area3} />
        <SecondaryPointBasic title="3.3  Zadanie 3" />
        <Section sections={sectionsTexts.sqlTask.area4} />
        <SecondaryPointBasic title="3.4  Zadanie 4" />
        <Section sections={sectionsTexts.sqlTask.area5} />
        <SecondaryPointBasic title="3.5  Zadanie 5" />
        <Section sections={sectionsTexts.sqlTask.area6} />
        <List
          listlinesText={listTexts.programmingTask.SQL.list1}
          listStyle="disc"
        />
        <SecondaryPointBasic title="3.6  Zadanie 6" />
        <Section sections={sectionsTexts.sqlTask.area7} />
        <List
          title={listTexts.programmingTask.SQL.list2Title}
          listlinesText={listTexts.programmingTask.SQL.list2}
          listStyle="disc"
        />
        <Section sections={sectionsTexts.sqlTask.area8} />
      </div>
    );
  }
}

export default SqlTasksSubPoints;
