import React, { Component } from 'react';
import SecondaryPoint from '../points/SecondaryPoint';
import Section from '../sections/Section';
import sectionsTexts from '../texts/sectionsTexts';
import listTexts from '../texts/listTexts';
import CodeComponent from '../sections/CodeComponent';
import List from '../lists/List';
import tabelTexts from '../texts/tabelTexts';
import Table from '../tabels/Tabel';

class JaxWSTaskSubPoint extends Component {
  state = {
    showPointContent: true
  };

  changeContentVisibility = () => {
    this.setState({
      showPointContent: !this.state.showPointContent
    });
  };

  render() {
    const { showPointContent } = this.state;

    return (
      <div>
        <SecondaryPoint
          title="2.2	Zadanie 2 - JAX-WS"
          showClickHandler={this.changeContentVisibility}
        />
        {showPointContent ? (
          <React.Fragment>
            <Section sections={sectionsTexts.programmingTask.area5} />
            <Section sections={sectionsTexts.programmingTask.area6} />

            <List
              title={listTexts.programmingTask.jaxWS.list1Title}
              listlinesText={listTexts.programmingTask.jaxWS.list1}
              listStyle="disc"
            />

            <Section sections={sectionsTexts.programmingTask.area7} />
            <Section sections={sectionsTexts.programmingTask.area8} />
            <CodeComponent />

            <List
              title={listTexts.programmingTask.jaxWS.list2Title}
              listlinesText={listTexts.programmingTask.jaxWS.list2}
              listStyle="disc"
            />
            <Table
              title={tabelTexts.programmingTask.jaxWS.tabel1Title}
              keyField={tabelTexts.programmingTask.jaxWS.tabel1keyField}
              columns={tabelTexts.programmingTask.jaxWS.tabel1Columns}
              data={tabelTexts.programmingTask.jaxWS.tabel1ColumnsData}
            />

            <Section sections={sectionsTexts.programmingTask.area9} />
            <List
              title={listTexts.programmingTask.jaxWS.list3Title}
              listlinesText={listTexts.programmingTask.jaxWS.list3}
              listStyle="disc"
            />
            <Section sections={sectionsTexts.programmingTask.area10} />
            <List
              title={listTexts.programmingTask.jaxWS.list4Title}
              listlinesText={listTexts.programmingTask.jaxWS.list4}
              listStyle="disc"
            />
            <Section sections={sectionsTexts.programmingTask.area11} />

            <Section sections={sectionsTexts.programmingTask.area12} />

            <List
              title={listTexts.programmingTask.jaxWS.list5Title}
              listlinesText={listTexts.programmingTask.jaxWS.list5}
              listStyle="disc"
            />

            <List
              title={listTexts.programmingTask.jaxWS.list6Title}
              listlinesText={listTexts.programmingTask.jaxWS.list6}
              listStyle="disc"
            />
          </React.Fragment>
        ) : null}
      </div>
    );
  }
}

export default JaxWSTaskSubPoint;
