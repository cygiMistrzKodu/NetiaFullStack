import React, { Component } from 'react';
import './CodeComponent.css';

class CodeComponent extends Component {
  render() {
    return (
      <div className="bgColor text-left">
        <pre>
          <code className="textColor">
            {`<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
          xmlns:int="https://netia.pl/">
        <soapenv:Header/>
        <soapenv:Body>
           <int:checkCustomerCreditionals>
              <username>?</username>
              <password>?</password>
           </int:checkCustomerCreditionals>
        </soapenv:Body>
        </soapenv:Envelope>`}
          </code>
        </pre>
      </div>
    );
  }
}

export default CodeComponent;
