import React, { Component } from 'react';

class Section extends Component {
  render() {

    let sectionList = this.props.sections.map(section => (
      <div key={section.id}>
        {section.text}
      </div>
    ));

    return (
      <div className="card-body d-flex flex-column align-self-center text-left">
        {sectionList}
      </div>
    );
  }
}

export default Section;