const sectionsTexts = {
  documentStructure: {
    area1: [
      {
        id: 1,
        text:
          'Dokument zawiera zadania rekrutacyjne na stanowiska związane z zatrudnieniem na stanowiska programistów.'
      }
    ]
  },
  programmingTask: {
    area1: [
      {
        id: 1,
        text:
          'Wykonanie poniższych zadań pozwoli ocenić umiejętności i/lub kreatywność kandydatów na stanowiska developerskie.'
      },
      {
        id: 2,
        text: 'Zadanie 2.1 należy zaimplementować w języku Python.'
      },
      {
        id: 3,
        text:
          'Zadania 2-4 powinny być  zaimplementowane w Javie w wersji 1.8 jako projekty Apache Maven. W nazwach projektów należy podać numer zadania, np. zadanie21, zadanie22, itd.'
      }
    ],
    area2: [
      {
        id: 1,
        text: 'Dla zadanych tablic wielowymiarowych :'
      }
    ],
    area3: [
      {
        id: 1,
        text:
          'Dane uzyskujemy poprzez wielowymiarowy indeks tablicy np. Abonament za Internet to dane[1][1] , kwota telewizji to dane[3][2].'
      }
    ],
    area4: [
      {
        id: 1,
        text:
          'Należy napisać program w języku Python, który dla zadanych tablic, na wyjście systemowe wyświetli podsumowanie kwotowe wg kategorii podsumowania, oraz te same dane zapisze w utworzonej przy uruchomieniu bazie SQLite (plik z baza ma pozostać po uruchomieniu aplikacji, w przypadku kolejnych uruchomień istniejący plik ma być nadpisywany) dla zadanych danych w kolejności sortowania podsumowania. Dane wejściowe należy umieścić w strukturach w kodzie źródłowym.'
      }
    ],
    area5: [
      {
        id: 1,
        text:
          'Należy zaimplementować aplikację typu WebService docelowo działającą na serwerze Tomcat7 w technologii Java 1.8.  Implementacja powinna być zgodna z dostarczonym WSDL (załącznik).'
      }
    ],
    area6: [
      {
        id: 1,
        text:
          'Należy dostarczyć kod źródłowy. Aplikacja zostanie oceniona względem kodu jak i prostoty kompilacji / działania na serwerze aplikacji. Jeśli kompilacja aplikacji będzie wymagała niestandardowych kroków / bibliotek lub innych akcji, należy dostarczyć kompaktową instrukcję kompilowania.'
      }
    ],
    area7: [
      {
        id: 1,
        text: 'Testy zostaną przeprowadzane przy pomocy aplikacji SoapUI.'
      }
    ],
    area8: [
      {
        id: 1,
        text: 'Interfejs  będzie odpytywany następującym żądaniem:'
      }
    ],
    area9: [
      {
        id: 1,
        text:
          'Dla zadanych powyżej loginów hasła inne niż podane powinny zwracać:'
      }
    ],
    area10: [
      {
        id: 1,
        text: 'Dla login6 zwracamy:'
      }
    ],
    area11: [
      {
        id: 1,
        text: 'Code: 8 description: Account Blocked'
      }
    ],
    area12: [
      {
        id: 1,
        text: "Jeśli login nie istnieje w 'źródle' danych, zwracamy:"
      }
    ],
    area13: [
      {
        id: 1,
        text:
          'Należy zaprojektować i napisać aplikację Java wraz ze schematem bazy danych, która z pobierze z lokalnej bazy adres w formacie wpisywanym w mapach gooogle (maps.google.com), a następnie wywoła API https://maps.googleapis.com/maps/api/geocode/json?address=wroc%C5%82aw,%20strzegomska%20142a i zapisze znormalizowany wynik z powrotem do BD.'
      }
    ],
    area14: [
      {
        id: 1,
        text:
          "Wraz z kodem aplikacji należy dostarczyć skrypt SQL tworzący struktury / bazę / użytkownika umożliwiającego uruchomienie i działanie aplikacji. Skrypt powinien być wykonywalny na 'gołej' instalacji bazy danych w wybranej technologii.  Jeśli skrypt jest potrzebny (W zależności o użytej technologii BD i sposobu implementacji)."
      }
    ],
    area15: [
      {
        id: 1,
        text:
          'Należy dostarczyć kod źródłowy. W przypadku nietrywialnej ścieżki kompilacji należy dostarczyć instrukcję kompilowania.'
      }
    ],
    area16: [
      {
        id: 1,
        text:
          'Metodologia/layout oraz użyte technologie frontendowe: dowolne. Nastawiamy się na prostotę/kompaktowość aplikacji i spełnienie wymagań.'
      }
    ],
    area17: [
      {
        id: 1,
        text:
          'Należy dostarczyć kod źródłowy oraz skompilowaną aplikację. W przypadku nietrywialnej ścieżki kompilacji należy dostarczyć instrukcję kompilowania..'
      }
    ]
  },
  sqlTask: {
    area1: [
      {
        id: 1,
        text:
          'Jako rozwiązanie do poszczególnych zadań należy przekazać pliki tekstowe zawierające zapytania realizujące dane zadanie w bazie danych utworzonej przez skrypt załączony w sekcji Załączniki. W nazwie pliku należy podać numer zadania.'
      },
      {
        id: 2,
        text:
          'Kod SQL należy dostosować do SZRBD PostgreSQL w wersji 9.6 (rozwiązanie można przetestować na przykład na stronie http://sqlfiddle.com).'
      }
    ],
    area2: [
      {
        id: 1,
        text:
          'Wylistować pracowników o nazwisku Kowalczyk, w wyniku kolumny id, imie, nazwisko posortowane według malejącej kolejności id.'
      }
    ],
    area3: [
      {
        id: 1,
        text:
          'Wylistować posortowaną alfabetycznie listę pracowników, których nazwisko występuje w bazie więcej niż raz wraz z ilością wystąpień, w wyniku kolumny: '
      },
      {
        id: 2,
        text: '* nazwisko '
      },
      {
        id: 3,
        text: '* ilosc_wystapien'
      }
    ],
    area4: [
      {
        id: 1,
        text:
          'Wylistować dzieci nie przypisane do żadnego rodzica – wszystkie kolumny z tabeli dzieci.'
      }
    ],
    area5: [
      {
        id: 1,
        text:
          'Wylistować pracowników nie posiadających dzieci – wszystkie kolumny z tabeli pracownicy.'
      }
    ],
    area6: [
      {
        id: 1,
        text:
          'Wylistować dane pracowników i ich dzieci jeden wiersz per dziecko, w wyniku:'
      }
    ],
    area7: [
      {
        id: 1,
        text:
          'Wylistować dzieci, które na dzień 1 grudnia 2017 nie mają ukończonych 18 lat. Z przypisaniem do grupy wiekowej:'
      },
      {
        id: 2,
        text: 'A – 0-5 lat'
      },
      {
        id: 3,
        text: 'B – 5-10 lat'
      },
      {
        id: 4,
        text: 'C – 10-18 lat'
      }
    ],
    area8: [
      {
        id: 5,
        text: 'Posortowana według grup wiekowych i wieku w latach.'
      }
    ]
  },
  frontendTask: {
    area1: [
      {
        id: 1,
        text:
          'Rozwiązania zadań należy dostarczyć w postaci archiwów zawierających komplet plików prezentujących rozwiązanie zadania. Utworzone strony powinny być zgodne ze standardem HTML5, w każdym z nich należy wykorzystać z Bootstrap, oraz dowolnego frameworka JavaScript.'
      }
    ],
    area2: [
      {
        id: 1,
        text:
          'Przygotować stronę prezentującą treść i formatowanie (logiczny układ dokumentu, nie dokładna prezentacja) niniejszego dokumentu przy wykorzystaniu HTML5/CSS Bootstrap. Za pomocą JavaScript zrealizować po stronie klienta:'
      }
    ],
    area3: [
      {
        id: 1,
        text:
          'Przygotować stronę z formularzem zawierającym pole tekstowe Po wpisaniu w pole dowolnego adresu i naciśnięciu przycisku enter strona powinna wywołać API: https://maps.googleapis.com/maps/api/geocode/json?address=wpisanyadres,%20pl&sensor=false i wyświetlić na stronie:'
      }
    ],
    area4: [
      {
        id: 1,
        text:
          'Aplikacja powinna obsłużyć przypadek w którym API zwróci wiele wyników – wyświetlić skróconą wersję wyniku (jedna linijka z wartościami a-d), po kliknięciu na pozycji wyświetlenie pełnych wyników, bez ponownego odpytania API.'
      }
    ]
  }
};

export default sectionsTexts;
