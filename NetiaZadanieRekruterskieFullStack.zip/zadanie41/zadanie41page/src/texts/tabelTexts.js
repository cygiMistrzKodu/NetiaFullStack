const tabelTexts = {
  programmingTask: {
    algorithmics: {
      tabel1Title: 'Dane:',
      tabel1keyField: 'indexiesField',
      tabel1Columns: [
        {
          dataField: 'indexiesField',
          text: 'indeksy',
        },
        {
          dataField: 'serviceNameField',
          text: '1'
        },
        {
          dataField: 'typeOfServiceField',
          text: '2'
        },
        {
          dataField: 'idnetifierField',
          text: '3'
        }
      ],
      tabel1ColumnsData: [
        {
          indexiesField: 1,
          serviceNameField: 'Abonament za Internet',
          typeOfServiceField: '40.00',
          idnetifierField: 1
        },
        {
          indexiesField: 2,
          serviceNameField: 'Bezpieczny Internet',
          typeOfServiceField: '9.90',
          idnetifierField: 3
        },
        {
          indexiesField: 3,
          serviceNameField: 'Telewizja Pakiet pełny',
          typeOfServiceField: '80.00',
          idnetifierField: 2
        },
        {
          indexiesField: 4,
          serviceNameField: 'GigaNagrywarka',
          typeOfServiceField: '15.00',
          idnetifierField: 2
        },
        {
          indexiesField: 5,
          serviceNameField: 'Rabat za Internet',
          typeOfServiceField: '-20.00',
          idnetifierField: 1
        }
      ],
      tabel1FooterDataTittle: 'Gdzie kolumny oznaczają odpowiednio:',
      tabel1FooterData: [
        {
          id: 1,
          text: ' - nazwa usługi'
        },
        {
          id: 2,
          text: ' - rodzaj usługi'
        },
        {
          id: 3,
          text: ' - słownik podsumowania - identyfikator'
        }
      ],
      tabel2Title: 'Podsumowanie:',
      tabel2keyField: 'indexiesField',
      tabel2Columns: [
        {
          dataField: 'indexiesField',
          text: 'indeksy'
        },
        {
          dataField: 'summaryPositionField',
          text: '1'
        },
        {
          dataField: 'idnetifierField',
          text: '2'
        },
        {
          dataField: 'sortingOrderToOutputField',
          text: '3'
        }
      ],
      tabel2ColumnsData: [
        {
          indexiesField: 1,
          summaryPositionField: 'Internet',
          idnetifierField: 1,
          sortingOrderToOutputField: 1
        },
        {
          indexiesField: 2,
          summaryPositionField: 'Usługi Dodatkowe',
          idnetifierField: 3,
          sortingOrderToOutputField: 2
        },
        {
          indexiesField: 3,
          summaryPositionField: 'Telewizja',
          idnetifierField: 2,
          sortingOrderToOutputField: 3
        }
      ],
      tabel2FooterDataTittle: 'Gdzie kolumny oznaczają odpowiednio:',
      tabel2FooterData: [
        {
          id: 1,
          text: ' - nazwa pozycji podsumowania'
        },
        {
          id: 2,
          text: ' - Identyfikator podsumowania'
        },
        {
          id: 3,
          text: ' - kolejność sortowania do wyjścia'
        }
      ],
      tabel3Title: 'Spodziewane wyjście:',
      tabel3keyField: 'summaryKategoryField',
      tabel3Columns: [
        {
          dataField: 'summaryKategoryField',
          text: 'Kategoria podsumowania'
        },
        {
          dataField: 'amountField',
          text: 'Kwota'
        }
      ],
      tabel3ColumnsData: [
        {
          summaryKategoryField: 'Internet',
          amountField: '20.00'
        },
        {
          summaryKategoryField: 'Usługi Dodatkowe',
          amountField: '9.90'
        },
        {
          summaryKategoryField: 'Telewizja',
          amountField: '95.00'
        }
      ],
      tabel3FooterDataTittle: 'Założenia:',
      tabel3FooterData: [
        {
          id: 1,
          text: 'Szerokość tablic z danymi powyżej zagnieżdżonych jest stała'
        },
        {
          id: 2,
          text: 'Dopuszczalne jest przepakowanie w inne struktury danych niż tablice wejściowe'
        }
      ]
    },
    jaxWS: {
      tabel1Title: 'powinna być zwracana dla następujących par:',
      tabel1keyField: 'loginField',
      tabel1Columns: [
        {
          dataField: 'loginField',
          text: 'Login'
        },
        {
          dataField: 'passField',
          text: 'Pass'
        }
      ],
      tabel1ColumnsData: [
        {
          loginField: 'login1',
          passField: 'pass1'
        },
        {
          loginField: 'login2',
          passField: 'pass2'
        },
        {
          loginField: 'login3',
          passField: 'pass3'
        },
        {
          loginField: 'login8',
          passField: 'du.8'
        },
        {
          loginField: 'login6',
          passField: 'badpass'
        }
      ]
    }
  }
};

export default tabelTexts;