const ListTexts = {
  programmingTask: {
    jaxWS: {
      list1Title: 'Mile widziane będą:',
      list1: [
        {
          id: 1,
          text: 'użycie technologii metro jax-ws  2.3.1'
        },
        {
          id: 2,
          text:
            'aplikacja nie powinna wymagać połączenia do źródeł danych (baza danych) - dane zwracane powinny być oparte o zahardkodowane wartości w reakcji na zadane parametry.'
        },
        {
          id: 3,
          text:
            'celujemy w plug&play z racji charakteru zadania i możliwości przetestowania aplikacji: aplikacja powinna być maksymalnie nastawiona na kompatybilność z ‘gołym’ serwerem Tomcat 7'
        }
      ],
      list2Title: 'Odpowiedź:',
      list2: [
        {
          id: 1,
          text: 'resCode:0'
        },
        {
          id: 2,
          text: 'resDescription: OK'
        }
      ],
      list3Title: 'Odpowiedź:',
      list3: [
        {
          id: 1,
          text: 'resCode:1'
        },
        {
          id: 2,
          text: 'resDescription: Wrong password'
        }
      ],
      list4Title: 'Odpowiedź:',
      list4: [
        {
          id: 1,
          text: 'resCode:8'
        },
        {
          id: 2,
          text: 'resDescription: Account Blocked'
        }
      ],
      list5Title: 'Odpowiedź:',
      list5: [
        {
          id: 1,
          text: 'resCode:5'
        },
        {
          id: 2,
          text: 'resDescription: NOT FOUND'
        }
      ],
      list6Title:
        'Dodatkowe podzadania / pytania na które należy odpowiedzieć wraz z implementacją:',
      list6: [
        {
          id: 1,
          text:
            'Jakie, czy i dlaczego ograniczenia można wprowadzić w parametrach metody checkCustomerCredentials'
        },
        {
          id: 2,
          text:
            'Z racji tematu aplikacji: Jakie wskazówki odnośnie bezpieczeństwa użycia aplikacji tego typu należałoby przekazać zespołowi wdrażającemu / administratorom aplikacji ?'
        }
      ]
    },
    dataProcessing: {
      list1Title: 'Należy zaprojektować:',
      list1Start: [
        {
          id: 1,
          text: 'schemat bazy (tabela / tabele):'
        }
      ],
      List1subList: [
        {
          id: 1,
          text:
            'Wejście: Tabela z wierszami zawierającymi dane adresowe w jednej kolumnie tekstowej oraz kolumny pomocnicze. Struktura do zaproponowania przez developera z uwzględnieniem masowego charakteru przetwarzania danych oraz wymagań raportu końcowego '
        },
        {
          id: 2,
          text:
            'Wyjście: zapis znormalizowanych danych pobranych przez API. Umiejscowienie, format i struktura oraz typy danych leżą w gestii developera.'
        }
      ],
      List1End: [
        {
          id: 1,
          text: 'Aplikację Java uruchamianą z linii komend (bez GUI)'
        }
      ],
      list2Title: 'Metoda działania:',
      list2: [
        {
          id: 1,
          text: 'pobieranie nieprzetworzonych danych z tabeli wejściowe'
        },
        {
          id: 2,
          text:
            'przetworzenie danych wejściowych przez API Google i zapisanie wyników przetworzenia w BD'
        }
      ],
      list3Title: 'Wskazówki / dodatkowe plusy:',
      list3: [
        {
          id: 1,
          text:
            'plik z konfiguracją aplikacji zewnętrzny wobec aplikacji (np namiary na BD / pliki wyjściowe z logami)'
        },
        {
          id: 2,
          text: 'logowanie przetwarzania: do pliku / na konsolę'
        },
        {
          id: 3,
          text:
            'Tryb pracy: ciągły w interwałach co X czasu na fetch / processing'
        },
        {
          id: 4,
          text:
            'dodatkowo punktowane: Przetwarzanie danych przez wiele instancji aplikacji uruchomionych na różnych serwerach korzystające z jednej bazy danych i tabeli źródłowej.'
        }
      ],
      list4Title: 'Ograniczenia:',
      list4: [
        {
          id: 1,
          text: 'Java 1.8'
        },
        {
          id: 2,
          text: 'Technologia bazy danych: PostgreSQL, MySQL/MariaDB lub SQLLite'
        }
      ],
      list5Title: 'Uwagi:',
      list5Start: [
        {
          id: 1,
          text:
            'Wsad należy zainicjować 100 rekordami z dowolnymi adresami w Polsce.'
        },
        {
          id: 2,
          text:
            'Należy przygotować zapytanie SQL/raport do wykonania w BD, które zwróci następujące kolumny:'
        }
      ],
      list5SubList: [
        {
          id: 1,
          text: 'o	id requestu wsadu,'
        },
        {
          id: 2,
          text: 'o	status przetworzenia,'
        },
        {
          id: 3,
          text: 'o	timestamp zakończenie przetworzenia, ,'
        },
        {
          id: 4,
          text: 'o	miasto,'
        },
        {
          id: 5,
          text: 'o	ulica,'
        },
        {
          id: 6,
          text: 'o	nr domu,'
        },
        {
          id: 7,
          text: 'o	lat,'
        },
        {
          id: 8,
          text: 'o	long,'
        }
      ],
      list5End: [
        {
          id: 1,
          text:
            'zapytanie raportowe bez ograniczeń: wyświetli wszystkie rekordy zawarte w tabeli wsadowej'
        },
        {
          id: 2,
          text:
            'należy zwrócić uwagę na ograniczenia API względem wolumenu odpytań i dostosować do niego aplikację.'
        }
      ]
    },
    WWW: {
      list1Title:
        'Należy przygotować stronę / aplikację na serwer Tomcat7, Java 1.7, która spełni następujące wymagania:',
      list1: [
        {
          id: 1,
          text: 'Umożliwi wyświetlanie danych wsadowych z tabeli zadania 3'
        },
        {
          id: 2,
          text:
            'Umożliwi dodanie nowych rekordów do wsadu z tabeli zadania 3 w formie formularza'
        },
        {
          id: 3,
          text: 'Umożliwi wyświetlanie raportu opisanego w zadaniu 3'
        }
      ],
      list2Title: 'Uwagi:',
      list2: [
        {
          id: 1,
          text:
            "Aplikacja w formie skompilowanej powinna uruchamiać się na 'gołym' serwerze Tomcat 7"
        },
        {
          id: 2,
          text:
            'Aplikacje z zadania 3 i 4 powinna korzystać z tej samej bazy danych.'
        }
      ]
    },
    SQL: {
      list1: [
        {
          id: 1,
          text: 'id dziecka'
        },
        {
          id: 2,
          text: 'imię dziecka'
        },
        {
          id: 3,
          text: 'data urodzenia'
        },
        {
          id: 4,
          text: 'imię pierwszego rodzica'
        },
        {
          id: 5,
          text: 'nazwisko pierwszego rodzica'
        },
        {
          id: 6,
          text: 'imię drugiego rodzica'
        },
        {
          id: 7,
          text: 'nazwisko drugiego rodzica'
        }
      ],
      list2Title: 'W wyniku:',
      list2: [
        {
          id: 1,
          text: 'id dziecka'
        },
        {
          id: 2,
          text: 'imię dziecka'
        },
        {
          id: 3,
          text: 'data urodzenia'
        },
        {
          id: 4,
          text: 'wiek w latach na 1 grudnia 2017'
        },
        {
          id: 5,
          text: 'grupa wiekowa A, B lub C'
        }
      ]
    },
    frontEnd: {
      list1: [
        {
          id: 1,
          text: 'Zwijanie/rozwijanie poszczególnych punktów'
        },
        {
          id: 2,
          text:
            'Sortowanie elementów w tabeli Definicje i skróty po kliknięciu na nagłówek kolumny.'
        }
      ],
      list2: [
        {
          id: 1,
          text: 'Miejscowość'
        },
        {
          id: 2,
          text: 'Nazwę ulicy'
        },
        {
          id: 3,
          text: 'Numer'
        },
        {
          id: 4,
          text: 'Kod pocztowy'
        },
        {
          id: 5,
          text: 'Współrzędne geograficzne'
        }
      ]
    }
  }
};

export default ListTexts;
