import React, { Component } from 'react';
import StructureAndRangePoint from './Document/StructureAndRangePoint';
import ProgrammingTasksPoint from './Document/ProgrammingTasksPoint';
import SqlTaskPoint from './Document/SqlTaskPoint';
import FrontEndTasksPoint from './Document/FrontEndTasksPoint';
import AttachmentPoint from './Document/AttachmentPoint';

import 'bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  render() {
    return (
      <div className="App text-center">
        <h1> Zadanie rekrutacyjne - Programista Fullstack </h1>
        <StructureAndRangePoint />
        <ProgrammingTasksPoint />
        <SqlTaskPoint />
        <FrontEndTasksPoint />
        <AttachmentPoint />
      </div>
    );
  }
}

export default App;

