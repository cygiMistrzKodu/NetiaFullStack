import React, { Component } from 'react';
import List from '../lists/List';
import BootstrapTable from 'react-bootstrap-table-next/dist/react-bootstrap-table-next';

class Tabel extends Component {
  render() {
    return (
      <div className="justify-content-center">
        <div>
          <h5 className="mb-0 mt-3">{this.props.title}</h5>
        </div>
        <div>
          <BootstrapTable
            bootstrap4
            keyField={this.props.keyField}
            columns={this.props.columns}
            data={this.props.data}
          />
        </div>
        <List
          title={this.props.tabelFooterTitle}
          listlinesText={this.props.footerData}
          listStyle={this.props.footerStyleType}
        />
      </div>
    );
  }
}

Tabel.defaultProps = {
  footerData: []
}

export default Tabel;
