U�y�em :
ReactJS, Boostrap4

�eby uruchomi� wersja developerska:

w konsoli:

Najpierw  npm install  ( instalacja modu��w : pojawi sie folder node_modules )

Nast�pnie npm start  ( uruchomi sie aplikacja wersja developerska adres  localhost:3000 )

-----------------------------------------------------------
Je�li zajdzie potrzeba u�ycia wersji zoptymalizowanej:

npm run build  
( zbuduje sie zoptymalizowna paczka. Pojawi sie folder build. Potem mo�na jej zawarto�c wrzuci� na serwer np. Tomcat do  folderu WebContent  )


---------
Polecam visual studio Code do analizy :)