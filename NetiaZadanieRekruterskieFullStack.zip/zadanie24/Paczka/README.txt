mo�na zmieni� port w configruation.properties

server.port = 8080