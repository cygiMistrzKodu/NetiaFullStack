package com.netia.zadanie24.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netia.zadanie24.entities.Address;
import com.netia.zadanie24.formsData.AddressForm;
import com.netia.zadanie24.repositories.AddressRepository;

@Service
public class AddressService {

	@Autowired
	private AddressRepository addressRepository;

	public List<Address> getAddresses() {

		return (List<Address>) addressRepository.findAll();
	}

	public void saveAddress(AddressForm addressForm) {

		Address address = new Address();

		address.setTown(addressForm.getTown());
		address.setStreet(addressForm.getStreet());
		address.setHouseNumber(addressForm.getHouseNumber());
		address.setGoogleFormatAdress(createGoogleAdress(addressForm));

		addressRepository.save(address);
	}

	private String createGoogleAdress(AddressForm addressForm) {

		String googleAdress = addressForm.getHouseNumber() + "+" + addressForm.getStreet() + "+"
				+ addressForm.getTown();

		googleAdress = googleAdress.replace(" ", "+");

		return googleAdress;
	}

}
