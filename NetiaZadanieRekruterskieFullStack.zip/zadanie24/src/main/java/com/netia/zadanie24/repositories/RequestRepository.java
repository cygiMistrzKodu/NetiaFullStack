package com.netia.zadanie24.repositories;

import org.springframework.data.repository.CrudRepository;

import com.netia.zadanie24.entities.Request;

public interface RequestRepository extends CrudRepository<Request, Long> {

}
