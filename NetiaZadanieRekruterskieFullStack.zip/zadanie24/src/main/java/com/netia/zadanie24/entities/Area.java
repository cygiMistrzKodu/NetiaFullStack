package com.netia.zadanie24.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Area {
	
	private Long id;
	private Location southWest;
	private Location northEast;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@OneToOne(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	public Location getSouthWest() {
		return southWest;
	}

	public void setSouthWest(Location southWest) {
		this.southWest = southWest;
	}

	@OneToOne(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	public Location getNorthEast() {
		return northEast;
	}

	public void setNorthEast(Location northEast) {
		this.northEast = northEast;
	}

}
