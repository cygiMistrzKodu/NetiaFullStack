package com.netia.zadanie24.entities;

public enum Status {

	PROCESSING, FINISHED, ERROR_PROCESSING

}
