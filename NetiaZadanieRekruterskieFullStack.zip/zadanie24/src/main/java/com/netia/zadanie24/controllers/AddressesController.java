package com.netia.zadanie24.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.netia.zadanie24.entities.Address;
import com.netia.zadanie24.services.AddressService;

@Controller
public class AddressesController {

	@Autowired
	private AddressService addressService;

	@RequestMapping("/")
	public String showAllAdresses(Map<String, Object> model) {

		List<Address> addresses = addressService.getAddresses();
		model.put("addressList", addresses);

		return "adresess";
	}

	@RequestMapping("/addressesList/refresh")
	public String refreshAdresses(ModelMap map) {

		List<Address> addresses = addressService.getAddresses();
		map.addAttribute("addressList", addresses);

		return "adresess :: #addressesId";
	}

}
