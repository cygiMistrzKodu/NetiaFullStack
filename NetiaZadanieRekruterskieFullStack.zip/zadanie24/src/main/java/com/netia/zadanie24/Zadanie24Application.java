package com.netia.zadanie24;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zadanie24Application {

	public static void main(String[] args) {
		SpringApplication.run(Zadanie24Application.class, args);
	}
}
