package com.netia.zadanie24.repositories;

import org.springframework.data.repository.CrudRepository;

import com.netia.zadanie24.entities.Address;

public interface AddressRepository extends CrudRepository<Address, Long>   {
    
	
}
