package com.netia.zadanie24.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.netia.zadanie24.formsData.AddressForm;
import com.netia.zadanie24.services.AddressService;

@RestController
public class AddAdressController {

	@Autowired
	private AddressService addressService;

	@PostMapping(value = "address/add")
	public Boolean addAdress(@RequestBody AddressForm addressForm) {

		addressService.saveAddress(addressForm);

		return true;
	}
}
