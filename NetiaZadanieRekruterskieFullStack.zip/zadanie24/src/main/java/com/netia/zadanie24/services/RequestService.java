package com.netia.zadanie24.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netia.zadanie24.entities.Request;
import com.netia.zadanie24.repositories.RequestRepository;

@Service
public class RequestService {

	@Autowired
	private RequestRepository requestRepository;
	
	public List<Request> getAllRequests() {
		
		return (List<Request>) requestRepository.findAll();
	}

}
