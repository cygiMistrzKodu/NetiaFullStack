function replaceContent(elementId, dataFragment) {

	let template = document.createElement('template');
	template.innerHTML = dataFragment;
	let newContent = template.content.firstChild;
	let oldContent = document.getElementById(elementId);
	oldContent.replaceWith(newContent);
}