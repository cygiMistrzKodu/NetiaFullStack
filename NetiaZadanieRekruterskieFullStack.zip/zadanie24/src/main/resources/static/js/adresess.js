
document.getElementById("refreshAddressList").addEventListener("click",
		updateAdressList);

document.getElementById("closeAddAdress").addEventListener("click",
		updateAdressList);

function updateAdressList() {

	fetch('/addressesList/refresh').then(function(response) {
		return response.text();
	}).then(function(adressList) {
		replaceContent("addressesId", adressList);
	});

}

$('#saveAdress').click(function(event) {
	let town = $('#town').val();
	let street = $('#street').val();
	let houseNumber = $('#houseNumber').val();
	let addres = {
		"town" : town,
		"street" : street,
		"houseNumber" : houseNumber
	};

	if (isAllMemmbersNotEmpty(addres)) {

		$.ajax({
			url : 'address/add',
			data : JSON.stringify(addres),
			type : "POST",
			contentType : "application/json",

			success : function(data) {

				$('#town').val("");
				$('#street').val("");
				$('#houseNumber').val("");
				$("#message").show().delay(2000).fadeOut();
			},
			error : function(e) {

				$("#error-message").show().delay(2000).fadeOut();

			}
		});

	} else {
		$("#error-field-empty").show().delay(1000).fadeOut();
	}

	event.preventDefault();
});

function isAllMemmbersNotEmpty(addres) {
		
	for(key in addres) {
		if (addres[key] == ""){
			return false
		}
	}
		
	return true;
}
