document.getElementById("refreshReportList").addEventListener("click",
		updateReportList);


function updateReportList() {

	fetch('/report/refresh').then(function(response) {
		return response.text();
	}).then(function(reportList) {
		replaceContent("reportsId", reportList);
	});

}
