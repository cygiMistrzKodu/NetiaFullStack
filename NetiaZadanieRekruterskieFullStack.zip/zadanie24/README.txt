Aplikacja u�ywa SPRING BOOT

Ju� skompilowana paczka folder -> Paczka

Aby uruchomic plik jar w folderze Paczka:

Uruchomienie komendy:

java -jar zadanie24-0.0.1-SNAPSHOT.war --spring.config.location=configuration.properties

parametr ->  --spring.config.location : pobiera konfiguracje z pliku

w pliku configuration.properties znajduj� si� klucze do konfiguracji : 
-> bazy

Kompilacja i uruchomienie kodu 
->  mvn spring-boot:run

sama kompilacja
-> mvn clean install

