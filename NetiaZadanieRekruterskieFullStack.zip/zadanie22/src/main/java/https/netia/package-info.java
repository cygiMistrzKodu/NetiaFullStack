@javax.xml.bind.annotation.XmlSchema(namespace = "https://netia.pl/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package https.netia;
