
package https.netia;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CredentialsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CredentialsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="resCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="resDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CredentialsResponse", propOrder = {
    "resCode",
    "resDescription"
})
public class CredentialsResponse {

    protected int resCode;
    protected String resDescription;

    /**
     * Gets the value of the resCode property.
     * 
     */
    public int getResCode() {
        return resCode;
    }

    /**
     * Sets the value of the resCode property.
     * 
     */
    public void setResCode(int value) {
        this.resCode = value;
    }

    /**
     * Gets the value of the resDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResDescription() {
        return resDescription;
    }

    /**
     * Sets the value of the resDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResDescription(String value) {
        this.resDescription = value;
    }

}
