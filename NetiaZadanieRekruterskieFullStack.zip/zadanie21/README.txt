U�y�em pythona 3.6

DO wy�wietlenia wyniku w konsoli u�y�em PrettyTable
Tak�e trzeba zainstalowa� komend�:

pip3 install PTable


----------------------------

Uruchomienie skrypt:  summary.py
----------------------------