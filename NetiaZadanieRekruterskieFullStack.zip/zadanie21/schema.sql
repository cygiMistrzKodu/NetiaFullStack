CREATE TABLE if not exists  SUMMARY (
 ID integer  primary key autoincrement not null ,
 kategoria_podsumowania text not null,
 kwota real);

