from prettytable import PrettyTable
import db_service

data = [["Abonament za Internet", 40.00, 1],
        ["Bezpieczny Internet", 9.90, 3],
        ["Telewizja Pakiet pełny", 80.00, 2],
        ["GigaNagrywarka", 15.00, 2],
        ["Rabat za Internet", -20.00, 1]]

summary = [["Internet", 1, 1],
           ["Usługi Dodatkowe", 3, 2],
           ["Telewizja", 2, 3]]

def IDENTIFIER_COLUMN():
    return 2


def COLUMN_IDENTIFIER_IN_SUMMARY():
    return 1


def calculate_price_for_service(amounts_for_id):
    flatten_prices = [j for sub in amounts_for_id for j in sub]
    return sum(flatten_prices)


services_with_prices = []
for rowInSummary in summary:
    amountsForID = [data[row][1:2] for row in range(0, 5) if
                    data[row][IDENTIFIER_COLUMN()] == rowInSummary[COLUMN_IDENTIFIER_IN_SUMMARY()]]
    service_price = calculate_price_for_service(amountsForID)
    services_with_prices.append([rowInSummary[0], service_price, rowInSummary[2]])


def sort_according_to_summary_order(services):
    return sorted(services, key=lambda x: x[2])


services_with_prices_sorted = sort_according_to_summary_order(services_with_prices)


def format_output_and_print(services):
    pt = PrettyTable()
    pt.field_names = ["Kategoria podsumowania", "Kwota"]
    for service in services:
        pt.add_row([service[0], service[1]])
    print(pt)


format_output_and_print(services_with_prices_sorted)
db_service.save(services_with_prices_sorted)
