import sqlite3

databaseName = 'summary.db'


def create_database_if_not_exist():
    schemaSql = open('schema.sql', 'r').read()
    connection = sqlite3.connect(databaseName)
    connection.execute(schemaSql)
    connection.commit()
    connection.close()


def get_connection():
    return sqlite3.connect(databaseName)


def delete_previous_summary(connection):
    connection.execute('''DELETE FROM SUMMARY''')


def save(categories):
    create_database_if_not_exist()
    connection = get_connection()
    delete_previous_summary(connection)
    for category in categories:
        connection.execute('''INSERT INTO SUMMARY (kategoria_podsumowania,kwota)
                    VALUES (?, ?)''', (category[0], category[1]))

    connection.commit()
    connection.close()
