﻿SELECT r.id,r.status, r.finished_time_stamp AS timestamp, a.town, a.street, a.house_number, l.lat, l.lng AS long
  FROM public.request r
  LEFT JOIN public.address a ON a.id = r.adress_id
  LEFT JOIN public.geocode g ON g.id = r.geocode_id
  LEFT JOIN public.geometry geom ON g.geometry_id = geom.id
  LEFT JOIN public.location l on l.id = geom.location_id; 