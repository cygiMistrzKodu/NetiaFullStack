﻿REVOKE ALL ON DATABASE "geocodeDB" FROM geocode_user;

DROP DATABASE "geocodeDB";

DROP ROLE geocode_user;
