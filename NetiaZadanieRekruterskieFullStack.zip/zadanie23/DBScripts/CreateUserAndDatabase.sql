﻿CREATE USER geocode_user WITH PASSWORD 'jacek' 
CREATEDB LOGIN;

CREATE DATABASE "geocodeDB"
  WITH OWNER = geocode_user
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'Polish_Poland.1250'
       LC_CTYPE = 'Polish_Poland.1250'
       CONNECTION LIMIT = -1;

 GRANT ALL ON DATABASE "geocodeDB" TO geocode_user;