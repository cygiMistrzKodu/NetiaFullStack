﻿
    create table address (
       id  bigserial not null,
        google_format_adress varchar(255),
        house_number int4,
        street varchar(255),
        town varchar(255),
        primary key (id)
    );

    create table address_component (
       id  bigserial not null,
        long_name varchar(255),
        short_name varchar(255),
        primary key (id)
    );

    create table address_component_types (
       address_component_id int8 not null,
        types varchar(255)
    );

    create table area (
       id  bigserial not null,
        north_east_id int8,
        south_west_id int8,
        primary key (id)
    );

    create table geocode (
       id  bigserial not null,
        formatted_address varchar(255),
        partial_match boolean,
        geometry_id int8,
        primary key (id)
    );

    create table geocode_address_components (
       geocode_id int8 not null,
        address_components_id int8 not null
    );

    create table geocode_types (
       geocode_id int8 not null,
        types varchar(255)
    );

    create table geometry (
       id  bigserial not null,
        location_type varchar(255),
        bounds_id int8,
        location_id int8,
        viewport_id int8,
        primary key (id)
    );

    create table location (
       id  bigserial not null,
        lat float8,
        lng float8,
        primary key (id)
    );

    create table request (
       id  bigserial not null,
        finished_time_stamp timestamp,
        status varchar(255),
        adress_id int8,
        geocode_id int8,
        primary key (id)
    );

    alter table if exists geocode_address_components 
       add constraint UK_9ojol7vdhb96q9y6xo1gddoi5 unique (address_components_id);

    alter table if exists address_component_types 
       add constraint FK8siss1ojhwjtcgxhfoobmgwc7 
       foreign key (address_component_id) 
       references address_component;

    alter table if exists area 
       add constraint FKpg7wgrft02lq2t5ui5kdw1cwl 
       foreign key (north_east_id) 
       references location;

    alter table if exists area 
       add constraint FKsd1vc0bdd3ns92xnlfjcxx31v 
       foreign key (south_west_id) 
       references location;

    alter table if exists geocode 
       add constraint FKpqtakokn97altwcv5l4t96it6 
       foreign key (geometry_id) 
       references geometry;

    alter table if exists geocode_address_components 
       add constraint FKokgiq2d576ybplyh34ycg4vn1 
       foreign key (address_components_id) 
       references address_component;

    alter table if exists geocode_address_components 
       add constraint FKospvu6wivu6obeanh2fugs0yg 
       foreign key (geocode_id) 
       references geocode;

    alter table if exists geocode_types 
       add constraint FKioh3vom59oicr2h46f4g37sy2 
       foreign key (geocode_id) 
       references geocode;

    alter table if exists geometry 
       add constraint FKs108dh5542btblorkfexqev82 
       foreign key (bounds_id) 
       references area;

    alter table if exists geometry 
       add constraint FK78i1wddf6v1fhrfu3nl355uns 
       foreign key (location_id) 
       references location;

    alter table if exists geometry 
       add constraint FKms46ymffq4xwkhk3ans4g11n2 
       foreign key (viewport_id) 
       references area;

    alter table if exists request 
       add constraint FKa5box98swtxsqt9m33of2cjcw 
       foreign key (adress_id) 
       references address;

    alter table if exists request 
       add constraint FKif9690p9jauvn5bms0q0usr58 
       foreign key (geocode_id) 
       references geocode;

ALTER TABLE public.location
  OWNER TO geocode_user;

ALTER TABLE public.address
  OWNER TO geocode_user;

 ALTER TABLE public.address_component
   OWNER TO geocode_user;

ALTER TABLE public.address_component_types
  OWNER TO geocode_user;

ALTER TABLE public.area
  OWNER TO geocode_user;

ALTER TABLE public.geocode
  OWNER TO geocode_user;

 ALTER TABLE public.geocode_address_components
  OWNER TO geocode_user;

ALTER TABLE public.geocode_types
  OWNER TO geocode_user;

ALTER TABLE public.geometry
  OWNER TO geocode_user;

ALTER TABLE public.request
  OWNER TO geocode_user;
