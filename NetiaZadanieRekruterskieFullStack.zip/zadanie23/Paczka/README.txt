-> miejsce na podanie klucza API Google w formie :
   
google.api.key = &key=[TutajKluczZApiGoogle]  ( znale�� wpis w configuration.properties )