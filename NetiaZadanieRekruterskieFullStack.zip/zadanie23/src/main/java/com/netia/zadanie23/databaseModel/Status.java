package com.netia.zadanie23.databaseModel;

public enum Status {

	PROCESSING, FINISHED, ERROR_PROCESSING

}
