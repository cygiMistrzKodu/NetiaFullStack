package com.netia.zadanie23.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netia.zadanie23.databaseModel.Address;
import com.netia.zadanie23.repositories.AdressRepository;

@Service
public class AdressService {

	@Autowired
	private AdressRepository adressRepository;

	public List<Address> getAddresses() {
			
		return (List<Address>) adressRepository.findAll();
	}
	
	public List<Address> getAdressesNotProcessed() {
		
		return (List<Address>) adressRepository.findAdressesNotProcessed();
	}

}
