package com.netia.zadanie23.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.netia.zadanie23.databaseModel.Address;

public interface AdressRepository extends CrudRepository<Address, Long> {
	
	@Query("SELECT a FROM Address a LEFT JOIN Request r ON a.id = r.adress Where r.adress IS NULL")
	List<Address> findAdressesNotProcessed();

}
