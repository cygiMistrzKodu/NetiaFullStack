package com.netia.zadanie23.databaseModel;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.netia.zadanie23.databaseModel.geoCode.Geocode;

@Entity
public class Request {

	private Long id;
	private Status status;
	private LocalDateTime finishedTimeStamp;
	private Address adress;
	private Geocode geocode;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Enumerated(EnumType.STRING)
	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	@Column(nullable = true)
	public LocalDateTime getFinishedTimeStamp() {
		return finishedTimeStamp;
	}

	public void setFinishedTimeStamp(LocalDateTime finishedTimeStamp) {
		this.finishedTimeStamp = finishedTimeStamp;
	}

	@OneToOne(cascade = CascadeType.MERGE, fetch=FetchType.LAZY)
	public Address getAdress() {
		return adress;
	}

	public void setAdress(Address adress) {
		this.adress = adress;
	}

	@OneToOne(cascade = CascadeType.MERGE, fetch=FetchType.LAZY)
	public Geocode getGeocode() {
		return geocode;
	}

	public void setGeocode(Geocode geocode) {
		this.geocode = geocode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adress == null) ? 0 : adress.hashCode());
		result = prime * result + ((finishedTimeStamp == null) ? 0 : finishedTimeStamp.hashCode());
		result = prime * result + ((geocode == null) ? 0 : geocode.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Request other = (Request) obj;
		if (adress == null) {
			if (other.adress != null)
				return false;
		} else if (!adress.equals(other.adress))
			return false;
		if (finishedTimeStamp == null) {
			if (other.finishedTimeStamp != null)
				return false;
		} else if (!finishedTimeStamp.equals(other.finishedTimeStamp))
			return false;
		if (geocode == null) {
			if (other.geocode != null)
				return false;
		} else if (!geocode.equals(other.geocode))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (status != other.status)
			return false;
		return true;
	}
	
	

}
