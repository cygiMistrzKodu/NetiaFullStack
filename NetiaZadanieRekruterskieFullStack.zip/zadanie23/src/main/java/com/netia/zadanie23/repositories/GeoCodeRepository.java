package com.netia.zadanie23.repositories;

import org.springframework.data.repository.CrudRepository;

import com.netia.zadanie23.databaseModel.geoCode.Geocode;


public interface GeoCodeRepository extends CrudRepository<Geocode, Long> {

}
