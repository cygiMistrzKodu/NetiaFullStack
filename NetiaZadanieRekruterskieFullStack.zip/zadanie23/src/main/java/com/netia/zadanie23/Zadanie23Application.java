package com.netia.zadanie23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zadanie23Application {

	public static void main(String[] args) {
		SpringApplication.run(Zadanie23Application.class, args);
	}
}
