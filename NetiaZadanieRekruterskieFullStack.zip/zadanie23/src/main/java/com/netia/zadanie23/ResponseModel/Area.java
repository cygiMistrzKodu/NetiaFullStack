package com.netia.zadanie23.ResponseModel;

public class Area {

	private Location southwest;
	private Location northeast;

	public Location getSouthWest() {
		return southwest;
	}

	public void setSouthWest(Location southWest) {
		this.southwest = southWest;
	}

	public Location getNorthEast() {
		return northeast;
	}

	public void setNorthEast(Location northEast) {
		this.northeast = northEast;
	}

}
