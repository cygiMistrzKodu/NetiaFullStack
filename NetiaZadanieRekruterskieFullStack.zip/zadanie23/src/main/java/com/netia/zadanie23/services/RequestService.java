package com.netia.zadanie23.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netia.zadanie23.databaseModel.Request;
import com.netia.zadanie23.repositories.RequestRepository;

@Service
public class RequestService {

	@Autowired
	private RequestRepository requestRepository;

	public void save(Request request) {

		 requestRepository.save(request);

	}

	public Request getRequestById(Long id) {

		return requestRepository.findById(id).get();
	}

}
