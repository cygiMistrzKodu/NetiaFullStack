Aplikacja u�ywa SPRING BOOT

Kompilacja i uruchomienie -> folderze root uruchomi� w konsoli komende  mvn spring-boot:run

Skrypty do tworzenia bazy ->  DBScripts

U�y�em bazy PostgreSQL 9.4

--------------------------------------------------------------------------------------------

Ju� skompilowana paczka folder -> Paczka

Aby uruchomic plik jar w folderze Paczka:

Uruchomienie komendy:

java -jar zadanie23-0.0.1-SNAPSHOT.jar --spring.config.location=configuration.properties

parametr ->  --spring.config.location : pobiera konfiguracje z pliku

w pliku configuration.properties znajduj� si� klucze do konfiguracji : 
-> bazy
-> sterowanie kolejk� ( pojemno��, szybko� pobierania i zapyta� do api google)

-> miejsce na podanie klucza API Google w formie :
   
  google.api.key = &key=[TutajKluczZApiGoogle] ( bez klucza mo�e dzia�a� ale nie daje gwarancji lepiej poda� )


-> mo�na te� ustawi� poziomy logowania
-> do jakiego pliku logowanie
-> wzorzecz logowania

------------------------------------------------------------------------------------------------------------

Kompilacja i uruchomienie kodu 
->  mvn spring-boot:run

sama kompilacja
-> mvn clean install
